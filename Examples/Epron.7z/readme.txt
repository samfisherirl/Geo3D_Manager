download httpsgithub.comsamfisherirlheresphere-auto-streamreleases

have heresphere open with the url bar selected, and have it cleared.

open up eporner.com in chrome.

go to your favorite video, and make sure you are logged in.

click go, put on your headset, repeat.

heresphere-auto-stream

